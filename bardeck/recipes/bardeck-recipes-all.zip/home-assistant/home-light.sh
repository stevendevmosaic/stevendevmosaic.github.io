#!/bin/zsh
# BarDeck live-data recipe: one light or switch from Home Assistant.   (example only, not supported: read it first)
# Usage: home-light.sh light.hall "Hall"        (entity id, then the name to show on the button)
# Set HA_URL to your Home Assistant address. The access token comes from the Keychain (see README), never from this file.
HA_URL="${HA_URL:-http://homeassistant.local:8123}"
ENTITY="${1:?usage: home-light.sh <entity_id> [name]}"
LABEL="${2:-$ENTITY}"
TOKEN="${HA_TOKEN:-$(security find-generic-password -s bardeck-homeassistant -w 2>/dev/null)}"
if [[ -z "$TOKEN" ]]; then
  print -r -- '{"label":"Home Assistant","value":"No token","detail":"see the README","color":"red"}'; exit 0
fi

# The header goes in through a pipe so the token never shows up in the process list.
RESPONSE=$(curl -fsS --max-time 8 -H @<(print -r -- "Authorization: Bearer $TOKEN") "$HA_URL/api/states/$ENTITY" 2>/dev/null) || {
  print -r -- '{"label":"Home Assistant","value":"Can'"'"'t reach","detail":"check HA_URL, token, entity","color":"red"}'; exit 0
}
print -r -- "$RESPONSE" |
LABEL="$LABEL" osascript -l JavaScript -e '
function run() {
  var d = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
  var j = JSON.parse($.NSString.alloc.initWithDataEncoding(d, 4).js);
  var label = $.NSProcessInfo.processInfo.environment.objectForKey("LABEL").js;
  var s = j.state, a = j.attributes || {}, detail = "", value, color;
  if (s === "on") {
    value = "On"; color = "yellow";
    if (typeof a.brightness === "number") detail = Math.round(a.brightness / 2.55) + "%";
  } else if (s === "off") { value = "Off"; color = "white"; }
  else if (s === "unavailable" || s === "unknown") { value = "No response"; color = "red"; }
  else { value = s; color = "cyan"; }
  return JSON.stringify({label: label, value: value, detail: detail, color: color});
}'
