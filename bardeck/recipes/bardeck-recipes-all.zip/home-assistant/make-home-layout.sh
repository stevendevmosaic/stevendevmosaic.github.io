#!/bin/zsh
# Makes a "Home" stack for BarDeck, one button per light, ready to import.   (example only, not supported)
# Usage: make-home-layout.sh light.hall:Hall light.landing:Landing switch.lamp:"Lounge lamp"
# Writes ~/BarDeckRecipes/home-layout.json. In BarDeck: menu > Import layout... > that file.
(( $# >= 1 )) || { echo 'usage: make-home-layout.sh light.hall:Hall switch.lamp:"Lounge lamp" ...'; exit 2; }
out="$HOME/BarDeckRecipes/home-layout.json"
first=1
{
  print -r -- '{"bardeckLayout":1,"exportedWith":"1.4","layout":{"buttons":[{"title":"Home","symbol":"house.fill","action":"group","children":['
  for pair in "$@"; do
    entity="${pair%%:*}"; name="${pair#*:}"; [[ "$pair" == *:* ]] || name="$entity"
    if [[ "$name" == *[\"\\\$\`]* ]]; then echo "Leave quotes, backslashes, \$ and backticks out of the names: $name"; exit 2; fi
    symbol="lightbulb.fill"; [[ "$entity" == switch.* ]] && symbol="powerplug.fill"
    (( first )) || print -r -- ","
    first=0
    print -rn -- "{\"title\":\"$name\",\"symbol\":\"$symbol\",\"action\":\"live\",\"argument\":\"~/BarDeckRecipes/home-light.sh $entity \\\"$name\\\"\",\"refresh\":15,\"onTap\":\"run:~/BarDeckRecipes/home-toggle.sh $entity\"}"
  done
  print -r -- ']}]}}'
} > "$out"
plutil -convert json -o /dev/null "$out" 2>/dev/null && echo "Wrote $out" || echo "That did not come out as valid JSON; check the entity ids and names."
