# Home: lights and plugs with their status (Home Assistant)

A **Home** stack on your bar. Each light or plug is a button that shows whether it is **On** (yellow, with brightness if it
has one), **Off**, or **No response**, and **a tap switches it**. *Example only, not supported.* Read the scripts first.
See `../README.md` for the general setup steps.

## What you need

* **Home Assistant** running on your network (a Raspberry Pi, a mini PC, Home Assistant Green or similar). It can also
  expose your HomeKit, Hue, IKEA, Tapo, Shelly and many other devices, so one recipe covers all of them.
* A Home Assistant **long-lived access token**: in Home Assistant click your name (bottom left) → **Security** →
  **Long-lived access tokens** → **Create token**. Copy it now; it is only shown once.
* The **entity id** of each light or plug: in Home Assistant, **Settings → Devices & services → Entities**; it looks like
  `light.hall` or `switch.lounge_lamp`.

## Setup (in addition to `../README.md`)

1. Put your token in the Keychain, not in any file. In Terminal:

       security add-generic-password -s bardeck-homeassistant -a token -w

   It asks for the token; paste it. The scripts read it from the Keychain each time. BarDeck never sees it.
2. Copy `home-light.sh`, `home-toggle.sh` and `make-home-layout.sh` into `~/BarDeckRecipes` and make them runnable:

       chmod +x ~/BarDeckRecipes/home-light.sh ~/BarDeckRecipes/home-toggle.sh ~/BarDeckRecipes/make-home-layout.sh

3. If your Home Assistant is not at `http://homeassistant.local:8123`, change `HA_URL` at the top of **both**
   `home-light.sh` and `home-toggle.sh` (for example `http://192.168.1.20:8123`).
4. Check one light from Terminal. You should see a line of JSON that says On or Off:

       ~/BarDeckRecipes/home-light.sh light.hall "Hall"

5. Make your stack. List each light as `entity_id:Name` (put a name with spaces in quotes):

       ~/BarDeckRecipes/make-home-layout.sh light.hall:Hall light.landing:Landing switch.lounge_lamp:"Lounge lamp"

   That writes `~/BarDeckRecipes/home-layout.json`.
6. In BarDeck, menu → **Import layout…** → choose `home-layout.json` → **Add to my layout**.
7. Open the **Home** stack. Each button says **Tap to allow**. Tap one, read the command, and choose **Allow**. Do this for
   each button (importing always clears approvals, on purpose).

Or skip steps 5 to 7 and use `button.json` from this folder as a starting point: it has two example lights.

## How it behaves

* Each button refreshes every 15 seconds, only while the bar is showing. After a tap the new state appears within a refresh.
* **No response** (red) means Home Assistant says the device is unavailable. **Can't reach** means the script could not
  talk to Home Assistant: check the address, the token and the entity id.
* The tap runs `home-toggle.sh`, which asks Home Assistant to toggle that entity. It works for lights, plugs, switches and
  fans. Set a button's *When tapped* to *Refresh now* in its edit window if you want a status-only button.

## If you don't use Home Assistant

* **Apple Home only:** BarDeck's **Run Shortcut** action can run a Shortcut that switches a light, so you can have
  on/off buttons. I have not found a way for Shortcuts to report whether a light is on, so those buttons cannot show a status.
* **Philips Hue, Shelly, Tasmota and others** have a local web address you can read and write. Copy `home-light.sh` and
  `home-toggle.sh` and change the `curl` lines; the output format is the same.
