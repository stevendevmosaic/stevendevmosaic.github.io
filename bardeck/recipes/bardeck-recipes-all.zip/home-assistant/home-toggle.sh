#!/bin/zsh
# BarDeck tap action: switch a Home Assistant light or switch on or off.   (example only, not supported)
# Usage: home-toggle.sh light.hall
HA_URL="${HA_URL:-http://homeassistant.local:8123}"
ENTITY="${1:?usage: home-toggle.sh <entity_id>}"
TOKEN="${HA_TOKEN:-$(security find-generic-password -s bardeck-homeassistant -w 2>/dev/null)}"
[[ -n "$TOKEN" ]] || exit 1
curl -fsS --max-time 8 -X POST -H @<(print -r -- "Authorization: Bearer $TOKEN") -H "Content-Type: application/json" \
  -d "{\"entity_id\":\"$ENTITY\"}" "$HA_URL/api/services/homeassistant/toggle" >/dev/null
