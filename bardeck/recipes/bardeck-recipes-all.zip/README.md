# BarDeck live-data recipes

Example scripts for BarDeck's **Live data** button. **They are examples, not part of BarDeck and not supported.**
Each one is a short script that prints a few lines of JSON; BarDeck runs it every so often and draws the result on a button.

**Read a script before you use it.** A live-data button runs whatever script you point it at, on your Mac, automatically.
These ones use tools every Mac already has (zsh, curl and `osascript`), except `tp-link-power`, which also needs Python 3 and
installs one small open-source library. Each talks only to the service named in its folder. Services change without notice, so a recipe can stop working; if one does, the fix is to edit the script.
No BarDeck update is needed.

| Recipe | Shows | Needs |
|---|---|---|
| `weather` | temperature, conditions, wind, today's chart | your latitude/longitude |
| `site-up` | UP / DOWN, HTTP status, response time | your web address |
| `tv-now-next` | what is on a UK channel now and next | a Sky channel number (list included) |
| `home-assistant` | lights and plugs with On/Off status, tap to switch (Home Assistant) | a Home Assistant address and token |
| `energy-glow` | live electricity use + today's cost, from a Bright/Glow smart meter | your Bright login (kept in the Keychain) |
| `tp-link-power` | live watts and kWh for each TP-Link Tapo smart plug, plus a total | Tapo plugs with energy monitoring, Python 3, your Tapo login (kept in the Keychain) |

## Or have Claude install it for you

If you use Claude (the desktop app's Code tab, or Claude Code), or another assistant that can read files and run commands
on your Mac, you can skip the steps below. Give it this zip and say: **"Install this BarDeck recipe for me."** It reads the
script, tells you what it does, asks you a couple of questions, sets it up and adds the button. You still tap
**Tap to allow** yourself, and anything that needs a password you type into Terminal yourself, never into the chat. The
instructions it follows are in `INSTALL-WITH-CLAUDE.md`. Only use zips downloaded from the BarDeck website.

## Set up any recipe (2 minutes)

1. Make a folder called `BarDeckRecipes` in your home folder and copy the recipe's `.sh` file into it.
2. Open the `.sh` file in TextEdit and change the settings at the top (place, address, channel…). Keep the plain straight quote marks around names: in TextEdit, first turn off Edit → Substitutions → Smart Quotes, or the script will break.
3. In Terminal, make it runnable once: `chmod +x ~/BarDeckRecipes/weather.sh` (use the file's own name).
4. In Terminal, check it works: `~/BarDeckRecipes/weather.sh`. You should see one line of JSON.
5. In BarDeck, menu → **Import layout…** → choose the recipe's `button.json` → **Add to my layout**.
6. The new button says **Tap to allow**. Tap it, read the command shown, and choose **Allow**.

Or skip steps 5 and 6: right-click the bar → **Add button…** → Action **Live data**, put
`~/BarDeckRecipes/weather.sh` in the command box, press **Test**, then **Add**.

## What a script must print

JSON, with any of these (all optional):

    {"label":"Electricity","value":"412 W","detail":"£0.31/kWh · today £2.18","color":"orange","spark":[1,2,3,2,4],"url":"https://…"}

* `label` small text on top (defaults to the button's title) · `value` the big text · `detail` the small line
* `color` one of cyan, orange, green, purple, red, yellow, white
* `spark` up to 60 numbers for the little chart · `url` an http(s) address a tap can open (set **When tapped** to *Open a link*, blank)

If it is not JSON, the first line becomes the value and the second the detail. Anything over 4 KB is cut off, and a script
that takes more than 15 seconds is stopped. A failing script keeps its last value, dimmed and marked "stale".

## Your own

Anything that prints text can be a button: a build status, a server check, a number from a spreadsheet, a count from
your inbox. Start from `site-up.sh`, the simplest one.
