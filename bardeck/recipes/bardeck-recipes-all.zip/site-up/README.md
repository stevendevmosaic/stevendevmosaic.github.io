# Is my site up?

Shows **UP** (green) or **DOWN** (red) with the HTTP status and response time. Tap opens the site if you set
*When tapped → Open a link* (the sample `button.json` does). *Example only, not supported.* Read `site-up.sh` first.
See `../README.md` for the setup steps.

Change `URL` at the top. To watch several sites, copy the script and the button once per site.
