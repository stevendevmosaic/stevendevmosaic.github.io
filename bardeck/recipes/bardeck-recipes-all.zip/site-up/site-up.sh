#!/bin/zsh
# BarDeck live-data recipe: is my website up?   (example only, not supported: read it before you use it)
# Shows UP/DOWN, the HTTP status and the response time. Change the address below.
URL="https://example.com"

out=$(curl -o /dev/null -s -L --max-time 10 -w '%{http_code} %{time_total}' "$URL") || out="000 0"
code=${out%% *}; secs=${out##* }
label=${URL#*://}; label=${label%%/*}
if [[ $code == 2* || $code == 3* ]]; then
  printf '{"label":"%s","value":"UP","detail":"%s · %.2f s","color":"green"}\n' "$label" "$code" "$secs"
else
  printf '{"label":"%s","value":"DOWN","detail":"%s","color":"red"}\n' "$label" "${code/000/no answer}"
fi
