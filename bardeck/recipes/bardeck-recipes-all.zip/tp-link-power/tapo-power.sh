#!/bin/zsh
# BarDeck live-data recipe: one Tapo plug's power from ~/.config/bardeck-recipes/tp-link-power.json, written by
# tapo_poller.py.   (example only, not supported)
# Usage: tapo-power.sh "Kettle"     (a plug's name in the Tapo app; or "TOTAL" for all plugs added together)
# Prints {"label","value","detail","color"} for the button.
NAME="$1" osascript -l JavaScript -e '
ObjC.import("Foundation");
var env = $.NSProcessInfo.processInfo.environment;
var name = ObjC.unwrap(env.objectForKey("NAME"));
var path = ObjC.unwrap($.NSHomeDirectory()) + "/.config/bardeck-recipes/tp-link-power.json";
function out(v, d, c) { return JSON.stringify({label: name, value: v, detail: d, color: c}); }
function norm(x) { return String(x).replace(/\s+/g, "").toLowerCase(); }
function fmt(w) { return w >= 1000 ? (w / 1000).toFixed(2) + " kW" : (w < 10 ? w.toFixed(1) : Math.round(w)) + " W"; }
function colour(w) { return w >= 1000 ? "red" : w >= 100 ? "orange" : w >= 3 ? "green" : "white"; }
var data = $.NSData.dataWithContentsOfFile(path);
if (!data || data.isNil()) { out("No data", "poller not running", "red"); }
else {
  var s = JSON.parse(ObjC.unwrap($.NSString.alloc.initWithDataEncoding(data, 4)));
  var age = (Date.now() - Date.parse(s.updated)) / 1000;
  if (age > 60) out("Paused", "poller is off", "white");
  else {
    var devs = s.devices || [];
    if (name === "TOTAL") {
      var w = 0, k = 0;
      devs.forEach(function (d) { if (d.energy) { w += d.energy.watts || 0; k += d.energy.today_kwh || 0; } });
      out(fmt(w), "today " + k.toFixed(2) + " kWh", colour(w));
    } else {
      var d = devs.filter(function (x) { return norm(x.name) === norm(name); })[0];
      if (!d) out("Unknown", "no such plug", "red");
      else if (!d.energy) out(d.on ? "On" : "Off", "no power data", d.on ? "yellow" : "white");
      else if (!d.on) out("Off", "today " + d.energy.today_kwh.toFixed(2) + " kWh", "white");
      else out(fmt(d.energy.watts), "today " + d.energy.today_kwh.toFixed(2) + " kWh", colour(d.energy.watts));
    }
  }
}' 2>/dev/null
