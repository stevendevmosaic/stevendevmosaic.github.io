#!/bin/zsh
# Starts and stops the Tapo poller (tapo_poller.py).   (BarDeck recipe: example only, not supported)
# Usage: poller.sh start | stop | toggle | status     ("status" prints live-data JSON for a BarDeck button)
# The poller runs as a launchd job so it keeps going after the button's own process ends. It only polls while it is running,
# so stop it when you don't need the readings.
LABEL=com.bardeck-recipes.tp-link-power
DIR="${0:A:h}"
LOG="$HOME/.config/bardeck-recipes/tp-link-power.log"
running() { pgrep -f "tapo_poller.py" >/dev/null; }
start() {
  running && return 0
  [[ -x "$DIR/venv/bin/python" ]] || { echo "Run setup.sh first."; return 1; }
  mkdir -p "${LOG:h}"
  launchctl remove $LABEL 2>/dev/null
  launchctl submit -l $LABEL -o "$LOG" -e "$LOG" -- "$DIR/venv/bin/python" "$DIR/tapo_poller.py"
}
stop() {
  launchctl remove $LABEL 2>/dev/null
  pkill -f "tapo_poller.py" 2>/dev/null
  return 0
}
case "$1" in
  start)  start ;;
  stop)   stop ;;
  toggle) if running; then stop; else start; fi ;;
  status)
    if running; then
      print -r -- '{"label":"Plug readings","value":"Running","detail":"tap to stop","color":"green"}'
    else
      print -r -- '{"label":"Plug readings","value":"Stopped","detail":"tap to start","color":"white"}'
    fi ;;
  *) echo "usage: $0 start|stop|toggle|status"; exit 2 ;;
esac
