#!/bin/zsh
# Makes a "Power" stack for BarDeck from the plugs the poller found, ready to import.   (example only, not supported)
# Run it after poller.sh start has been going for 20 seconds. Writes ~/BarDeckRecipes/tp-link-power/power-layout.json.
# In BarDeck: menu > Import layout... > that file.
DIR="${0:A:h}"
DATA="$HOME/.config/bardeck-recipes/tp-link-power.json"
[[ -f "$DATA" ]] || { echo "No readings yet. Run ./poller.sh start and wait about 20 seconds."; exit 1; }
DIR="$DIR" DATA="$DATA" osascript -l JavaScript -e '
ObjC.import("Foundation");
var env = $.NSProcessInfo.processInfo.environment;
var dir = ObjC.unwrap(env.objectForKey("DIR")), data = ObjC.unwrap(env.objectForKey("DATA"));
function read(p) { return ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError(p, 4, null)); }
var devs = JSON.parse(read(data)).devices || [];
function live(title, symbol, cmd, tap) {
  var b = {title: title, symbol: symbol, action: "live", argument: cmd, refresh: 15};
  if (tap) b.onTap = tap;
  return b;
}
var kids = [live("TOTAL", "bolt.fill", dir.replace(ObjC.unwrap($.NSHomeDirectory()), "~") + "/tapo-power.sh \"TOTAL\"")];
var home = ObjC.unwrap($.NSHomeDirectory());
devs.forEach(function (d) {
  if (/["\\$`]/.test(d.name)) return;          // a name with a quote, backslash, $ or backtick would break the command
  kids.push(live(d.name, "powerplug.fill", dir.replace(home, "~") + "/tapo-power.sh \"" + d.name + "\""));
});
kids.push(live("Plug readings", "arrow.triangle.2.circlepath", dir.replace(home, "~") + "/poller.sh status", "run:" + dir.replace(home, "~") + "/poller.sh toggle"));
var layout = {bardeckLayout: 1, exportedWith: "1.4", layout: {buttons: [{title: "Power", symbol: "bolt.fill", action: "group", children: kids}]}};
var out = dir + "/power-layout.json";
$.NSString.alloc.initWithUTF8String(JSON.stringify(layout, null, 2)).writeToFileAtomicallyEncodingError(out, true, 4, null);
"Wrote " + out + " with " + (kids.length - 2) + " plug(s)."
' || exit 1
