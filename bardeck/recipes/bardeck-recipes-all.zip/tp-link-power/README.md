# Power: TP-Link Tapo smart plugs, live watts and kWh

A **Power** stack on your bar. Each Tapo smart plug is a button showing what it is using **right now** (watts, coloured by how
much) and today's kWh, plus a **TOTAL** for the lot. *Example only, not supported.* Read the scripts first.
See `../README.md` for the general setup steps.

## What you need

* **TP-Link Tapo smart plugs with energy monitoring** (P110, P110M, P304M and similar). Plugs without it still work but only
  show On or Off.
* In the **Tapo app**: **Me → Third-Party Services → Third-Party Compatibility** switched **on**. Without it the plugs refuse
  local logins.
* **Python 3.** If Terminal says `python3` is missing, run `xcode-select --install` (Apple's free command line tools).
* Your **Tapo account email and password**. They go in your Mac's Keychain, never in a file, and are only used to talk to the
  plugs over your home network.

## Setup (in addition to `../README.md`)

1. Copy this whole `tp-link-power` folder into `~/BarDeckRecipes`.
2. In Terminal, run the setup (it makes a private Python environment inside the folder and installs
   [python-kasa](https://github.com/python-kasa/python-kasa), the open-source library that talks to Tapo plugs; it asks for your
   Tapo email and password once and stores them in the Keychain):

       cd ~/BarDeckRecipes/tp-link-power
       chmod +x setup.sh
       ./setup.sh

3. Start the poller and give it about 20 seconds to find your plugs:

       ./poller.sh start
       ./tapo-power.sh TOTAL

   You should see a line of JSON with your total watts. If it says **Paused** or **No data**, wait a little longer, then check
   the **Third-Party Compatibility** setting and that the Mac is on the same network as the plugs.
4. Make your stack from the plugs it found:

       ./make-power-layout.sh

   That writes `power-layout.json`, one button per plug, a **TOTAL** button and a **Plug readings** button.
5. In BarDeck, menu → **Import layout…** → choose `power-layout.json` → **Add to my layout**.
6. Open the **Power** stack. Each button says **Tap to allow**. Tap one, read the command, and choose **Allow**. Do this for
   each button (importing always clears approvals, on purpose).

Or skip steps 4 to 6 and use `button.json` as a starting point: it has **TOTAL** and the **Plug readings** button.

## How it behaves

* The **poller** is a small background job that reads your plugs every 10 seconds and writes the result to
  `~/.config/bardeck-recipes/tp-link-power.json`. The buttons read that file, so they are instant and the plugs are not asked
  more often than that.
* **Plug readings** shows whether the poller is running; tapping it starts or stops it. **It only polls while it is running**,
  so stop it when you don't need the numbers. It does not restart by itself after a restart of your Mac.
* A plug button shows watts and today's kWh: **green** when on, **orange** above 100 W, **red** above 1 kW, **white** when off or
  idle. The button's name must match the plug's name in the Tapo app (the layout maker copies the names for you).
* **Paused / poller is off** means the readings are older than a minute: start the poller.
* Tapping a plug button only refreshes it. It does not switch the plug.

## If something is wrong

* **No Keychain item** in the poller's log (`~/.config/bardeck-recipes/tp-link-power.log`): run `./setup.sh` again.
* **No plugs found**: the Mac and plugs must be on the same network (not a guest network), and Third-Party Compatibility must
  be on. Tapo plugs can take a minute to answer the first time.
* A plug is missing from the layout: it was off the network when the poller searched. It searches again every 10 minutes;
  run `./make-power-layout.sh` again afterwards.
