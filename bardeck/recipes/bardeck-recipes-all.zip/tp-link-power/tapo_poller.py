#!/usr/bin/env python3
"""Polls TP-Link Tapo smart plugs (P110, P110M, P304M and similar) on your home network and writes their power use to a JSON
file that tapo-power.sh reads.   (BarDeck recipe: example only, not supported)

Login: macOS Keychain item, service "bardeck-tapo" (account = your Tapo email, password = your Tapo password). It is read
from the Keychain each time the poller starts and is never written to a file.
Needs "Third-Party Compatibility" switched on in the Tapo app so the plugs accept local logins.
Output: ~/.config/bardeck-recipes/tp-link-power.json, rewritten every POLL seconds. Start and stop it with poller.sh.
"""
import asyncio, datetime, json, os, re, subprocess, sys, time

from kasa import Credentials, Discover

POLL = 10                # seconds between readings
REDISCOVER = 600         # seconds between full searches of the network
OUT = os.path.expanduser("~/.config/bardeck-recipes/tp-link-power.json")
SERVICE = "bardeck-tapo"


def keychain_credentials():
    meta = subprocess.run(["security", "find-generic-password", "-s", SERVICE], capture_output=True, text=True)
    m = re.search(r'"acct"<blob>="([^"]*)"', meta.stdout)
    pw = subprocess.run(["security", "find-generic-password", "-s", SERVICE, "-w"], capture_output=True, text=True)
    if not m or pw.returncode != 0:
        sys.exit(f"No Keychain item '{SERVICE}'. Add it with:\n"
                 f"  security add-generic-password -s {SERVICE} -a 'your-tapo-email' -w")
    return Credentials(m.group(1), pw.stdout.rstrip("\n"))


def energy(dev):
    e = dev.modules.get("Energy")
    if not e:
        return None
    return {"watts": e.current_consumption, "today_kwh": e.consumption_today, "month_kwh": e.consumption_this_month}


async def read_device(ip, dev):
    """One row for a plug, or one per outlet for a power strip."""
    await dev.update()
    if dev.children:
        return [{"name": c.alias, "ip": ip, "model": dev.model, "parent": dev.alias, "on": c.is_on, "energy": energy(c)}
                for c in dev.children]
    return [{"name": dev.alias, "ip": ip, "model": dev.model, "parent": None, "on": dev.is_on, "energy": energy(dev)}]


def write(rows, errors):
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = {"updated": datetime.datetime.now(datetime.timezone.utc).isoformat(), "devices": rows, "errors": errors}
    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(doc, f)
    os.replace(tmp, OUT)


async def main():
    creds = keychain_credentials()
    devices, last_discovery = {}, 0.0
    while True:
        if time.time() - last_discovery > REDISCOVER or not devices:
            for d in devices.values():
                try:
                    await d.disconnect()
                except Exception:
                    pass
            devices = await Discover.discover(credentials=creds, discovery_timeout=8)
            last_discovery = time.time()
        rows, errors = [], {}

        async def one(ip, dev):
            try:
                return ip, await read_device(ip, dev), None
            except Exception as ex:
                return ip, [], str(ex)

        for ip, got, err in await asyncio.gather(*(one(i, d) for i, d in devices.items())):
            rows += got
            if err:
                errors[ip] = err
        write(rows, errors)
        if errors and len(errors) == len(devices):
            last_discovery = 0          # everything failed: search again next time round
        await asyncio.sleep(POLL)


if __name__ == "__main__":
    asyncio.run(main())
