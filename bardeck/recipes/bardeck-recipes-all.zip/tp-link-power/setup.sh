#!/bin/zsh
# One-time setup for the TP-Link power recipe.   (BarDeck recipe: example only, not supported)
# Makes a private Python environment in this folder, installs python-kasa (the open-source library that talks to Tapo plugs)
# into it, and puts your Tapo login in the Keychain. Nothing is installed anywhere else.
cd "${0:A:h}" || exit 1
command -v python3 >/dev/null || { echo "python3 is missing. Install Apple's command line tools: xcode-select --install"; exit 1; }
if [[ ! -x venv/bin/python ]]; then
  echo "Making the Python environment..."
  python3 -m venv venv || exit 1
fi
echo "Installing python-kasa..."
venv/bin/python -m pip install --quiet --upgrade pip python-kasa || exit 1
if security find-generic-password -s bardeck-tapo >/dev/null 2>&1; then
  echo "Your Tapo login is already in the Keychain (service bardeck-tapo)."
else
  printf "Your Tapo account email: "
  read -r email
  echo "Now your Tapo password (typed hidden, stored only in your Keychain):"
  security add-generic-password -s bardeck-tapo -a "$email" -w || exit 1
fi
chmod +x poller.sh tapo-power.sh make-power-layout.sh
echo "Done. Next: ./poller.sh start, wait about 20 seconds, then ./tapo-power.sh TOTAL"
