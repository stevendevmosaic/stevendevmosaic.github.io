# Electricity: Bright / Glow smart meter

Live electricity use in W/kW, today's cost and kWh, and a chart of today's half-hours. *Example only, not supported.*

**What it does:** signs in to the same web service the Bright app uses (Hildebrand Glowmarkt) with your own Bright
login and reads your meter's readings. **Warning:** that service is not a published API for outsiders; it can change
or stop without notice. Read `energy-glow.sh` before using it.

## Setup (in addition to `../README.md`)

1. Keep your Bright login in the Keychain, not in any file. In Terminal (use your real Bright email address):

       security add-generic-password -s glowmarkt-bright -a "you@example.com" -w

   It asks for your password. The script reads it from the Keychain each time it needs to sign in; BarDeck never sees it.
2. Optional: tell it your tariff, in `~/.config/glow/tariff.json`:

       {"dayPence": 30.78, "nightPence": 6.66, "nightStart": "23:00", "nightEnd": "06:00", "standingPence": 61.12, "includeStanding": false}

   Rates are pence per kWh. Without this file it assumes a flat 28 p/kWh.
3. The first run may ask for permission to read the Keychain item. Choose **Always Allow**.

The script keeps a sign-in token and your meter's id in `~/.config/bardeck-recipes/` (readable only by you) so each
refresh is just two quick requests. Delete that folder to start over. Suggested refresh: 30 seconds.
