#!/bin/zsh
# BarDeck live-data recipe: live electricity use and today's cost from a Bright / Glow smart-meter display (Hildebrand Glowmarkt).
# (example only, not supported: it uses the same web service the Bright app uses, which can change without notice)
#
# One-off setup, in Terminal (your Bright login is kept in your Mac's Keychain, never in this file or in BarDeck):
#     security add-generic-password -s glowmarkt-bright -a "you@example.com" -w
#   (it asks for your Bright password; use your real login email in place of you@example.com)
# Optional: your tariff in ~/.config/glow/tariff.json, for example
#     {"dayPence": 30.78, "nightPence": 6.66, "nightStart": "23:00", "nightEnd": "06:00", "standingPence": 61.12, "includeStanding": false}
# Without that file it shows a plain 28.0p/kWh and no night rate.

APP="b0f1b774-a586-4f72-9edd-27ead8aa7a8d"        # the public application id of the Bright app
API="https://api.glowmarkt.com/api/v0-1"
CACHE="$HOME/.config/bardeck-recipes"; mkdir -p "$CACHE"

fail() { printf '{"label":"Electricity","value":"no data","detail":"%s","color":"red"}\n' "$1"; exit 0; }

jget() { osascript -l JavaScript -e 'function run(a){var d=$.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;var j=JSON.parse($.NSString.alloc.initWithDataEncoding(d,4).js);return String(j[a[0]]);}' "$1"; }
get() { curl -fsS --max-time 13 -H "applicationId: $APP" -H "token: $TOKEN" "$API/$1"; }

# the sign-in token is kept between runs (it lasts a long time) so each refresh is only two quick requests
login() {
  local u p
  u=$(security find-generic-password -s glowmarkt-bright 2>/dev/null | sed -n 's/.*"acct"<blob>="\(.*\)"/\1/p')
  p=$(security find-generic-password -s glowmarkt-bright -w 2>/dev/null)
  [[ -n $u && -n $p ]] || fail "No login in Keychain (see the top of this script)"
  TOKEN=$(curl -fsS --max-time 12 -H "applicationId: $APP" -H "Content-Type: application/json" \
    -d "$(printf '{"username":"%s","password":"%s"}' "$u" "${p//\"/\\\"}")" "$API/auth" 2>/dev/null | jget token 2>/dev/null)
  [[ -n $TOKEN && $TOKEN != undefined ]] || fail "Sign-in failed"
  print -r -- "$TOKEN" > "$CACHE/glow-token"; chmod 600 "$CACHE/glow-token"
}
TOKEN=$(cat "$CACHE/glow-token" 2>/dev/null)
[[ -n $TOKEN ]] || login
get virtualentity >/dev/null 2>&1 || login      # an expired token: sign in again once

# the electricity resource id never changes, so it is looked up once and kept
RES=$(cat "$CACHE/glow-resource" 2>/dev/null)
if [[ -z $RES ]]; then
  for ve in $(get virtualentity | osascript -l JavaScript -e 'function run(){var d=$.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;return JSON.parse($.NSString.alloc.initWithDataEncoding(d,4).js).map(function(v){return v.veId}).join(" ")}'); do
    RES=$(get "virtualentity/$ve/resources" | osascript -l JavaScript -e 'function run(){var d=$.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;var r=JSON.parse($.NSString.alloc.initWithDataEncoding(d,4).js).resources.filter(function(x){return x.classifier=="electricity.consumption"})[0];return r?r.resourceId:""}')
    [[ -n $RES ]] && break
  done
  [[ -n $RES ]] && print -r -- "$RES" > "$CACHE/glow-resource"
fi
[[ -n $RES ]] || fail "No electricity meter found"

# today's half-hourly readings, from local midnight
FROM=$(date -u -r "$(date -v0H -v0M -v0S +%s)" +%Y-%m-%dT%H:%M:%S); TO=$(date -u +%Y-%m-%dT%H:%M:%S)
# "current" can be slow (the meter is asked for a fresh reading), so both requests run at once
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
get "resource/$RES/current" > "$T/cur" 2>/dev/null &
get "resource/$RES/readings?from=$FROM&to=$TO&period=PT30M&offset=0&function=sum" > "$T/slots" 2>/dev/null &
wait
{ cat "$T/cur"; echo; cat "$T/slots"; echo; } |
TARIFF="$HOME/.config/glow/tariff.json" osascript -l JavaScript -e '
function run() {
  var d = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
  var lines = $.NSString.alloc.initWithDataEncoding(d, 4).js.split("\n").filter(function (l) { return l.trim(); });
  function parse(l) { try { return JSON.parse(l).data; } catch (e) { return null; } }
  var cur = parse(lines[0]), slots = parse(lines[1]) || [];
  var t = {dayPence: 28, nightPence: 28, nightStart: "23:00", nightEnd: "06:00", standingPence: 0, includeStanding: false};
  var raw = $.NSString.stringWithContentsOfFileEncodingError($.NSProcessInfo.processInfo.environment.objectForKey("TARIFF"), 4, null);
  if (raw) { var o = JSON.parse(raw.js); for (var k in o) t[k] = o[k]; }
  function mins(s) { var p = s.split(":"); return +p[0] * 60 + +p[1]; }
  var a = mins(t.nightStart), b = mins(t.nightEnd);
  function rate(ts) {
    var x = new Date(ts * 1000), m = x.getHours() * 60 + x.getMinutes();
    var night = a > b ? (m >= a || m < b) : (m >= a && m < b);
    return night ? t.nightPence : t.dayPence;
  }
  var kwh = 0, pence = 0, spark = [];
  slots.forEach(function (s) { kwh += s[1]; pence += s[1] * rate(s[0]); spark.push(+s[1].toFixed(3)); });
  if (t.includeStanding) pence += t.standingPence;
  var w = cur && cur[0] ? cur[0][1] : null;
  if (w === null && !slots.length) return JSON.stringify({label: "Electricity", value: "no data", detail: "The service did not answer", color: "red"});
  if (w === null) return JSON.stringify({label: "Electricity", value: "–", detail: "£" + (pence / 100).toFixed(2) + " today · live reading unavailable", color: "orange", spark: spark});
  return JSON.stringify({
    label: "Electricity",
    value: w >= 1000 ? (w / 1000).toFixed(2) + " kW" : Math.round(w) + " W",
    detail: "£" + (pence / 100).toFixed(2) + " today · " + kwh.toFixed(1) + " kWh",
    color: w < 400 ? "green" : (w < 1500 ? "orange" : "red"),
    spark: spark
  });
}'
