# Weather (Open-Meteo)

Temperature, conditions, wind and today's temperature chart. Uses the free, key-less [Open-Meteo](https://open-meteo.com) service.
*Example only, not supported.* Read `weather.sh` before using it. See `../README.md` for the setup steps.

Change `PLACE`, `LAT` and `LON` at the top of `weather.sh` (in Maps, right-click your town and choose "What's here?" for the numbers).
Suggested refresh: 10 minutes (the forecast does not move faster than that).
