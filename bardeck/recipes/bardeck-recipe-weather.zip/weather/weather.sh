#!/bin/zsh
# BarDeck live-data recipe: weather from Open-Meteo (free, no key).   (example only, not supported: read it first)
# Set your place's latitude and longitude (find them in Maps: right-click > "What's here?").
PLACE="Glasgow"
LAT=55.86
LON=-4.25

RESPONSE=$(curl -fsS --max-time 10 "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code,wind_speed_10m&hourly=temperature_2m&forecast_days=1&timezone=auto") || {
  print -r -- "{\"label\":\"$PLACE\",\"value\":\"No data\",\"detail\":\"can't reach Open-Meteo\",\"color\":\"red\"}"; exit 0
}
print -r -- "$RESPONSE" |
PLACE="$PLACE" osascript -l JavaScript -e '
function run() {
  var d = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
  var j = JSON.parse($.NSString.alloc.initWithDataEncoding(d, 4).js);
  var codes = {0:"Clear",1:"Mostly clear",2:"Partly cloudy",3:"Cloudy",45:"Fog",48:"Fog",51:"Drizzle",53:"Drizzle",55:"Drizzle",
    61:"Light rain",63:"Rain",65:"Heavy rain",71:"Light snow",73:"Snow",75:"Heavy snow",80:"Showers",81:"Showers",82:"Heavy showers",
    95:"Thunderstorm",96:"Thunderstorm",99:"Thunderstorm"};
  var c = j.current, t = Math.round(c.temperature_2m);
  return JSON.stringify({
    label: $.NSProcessInfo.processInfo.environment.objectForKey("PLACE").js,
    value: t + "°C",
    detail: (codes[c.weather_code] || "Weather") + " · wind " + Math.round(c.wind_speed_10m) + " km/h",
    color: t <= 3 ? "cyan" : (t >= 24 ? "orange" : "green"),
    spark: j.hourly.temperature_2m
  });
}' 2>/dev/null || print -r -- "{\"label\":\"$PLACE\",\"value\":\"No data\",\"detail\":\"unexpected reply\",\"color\":\"red\"}"
