# TV now and next (UK, Sky listings)

What is on a channel now (until when, minutes left) and what is next. *Example only, not supported.*

**Warning:** this reads Sky's public listings feed, which is unofficial. It can change or stop without notice, and the
listings are Sky's, for personal use. Read `tv-now-next.sh` before using it. See `../README.md` for the setup steps.

Change `SID` and `NAME` at the top. The channel numbers (Central Scotland listing; other regions differ slightly) are in
`channels.txt`. For several channels, copy the script (`tv-bbc1.sh`, `tv-stv.sh`…) with a different `SID` each.
