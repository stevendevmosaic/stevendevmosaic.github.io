#!/bin/zsh
# BarDeck live-data recipe: what is on a UK TV channel now, and next, from Sky's public listings feed.
# (example only, not supported: it is an UNOFFICIAL feed that can change or stop without notice)
# SID is Sky's channel number from the listing: 2082 BBC One Scotland, 2075 BBC Two, 6210 STV, 1248 Channel 4, 2086 BBC Four,
# 3021 BBC ALBA. The full list is in channels.txt beside this script.
SID=2075
NAME="BBC Two"

today=$(date +%Y%m%d); tomorrow=$(date -v+1d +%Y%m%d)
{ curl -fsS --max-time 10 "https://awk.epgsky.com/hawk/linear/schedule/$today/$SID"; echo
  curl -fsS --max-time 10 "https://awk.epgsky.com/hawk/linear/schedule/$tomorrow/$SID"; echo; } |
NAME="$NAME" osascript -l JavaScript -e '
function run() {
  var d = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
  var text = $.NSString.alloc.initWithDataEncoding(d, 4).js;
  var events = [];
  text.split("\n").forEach(function (l) {
    if (!l.trim()) return;
    var j = JSON.parse(l);
    ((j.schedule && j.schedule[0] && j.schedule[0].events) || []).forEach(function (e) { events.push(e); });
  });
  events.sort(function (a, b) { return a.st - b.st; });
  var now = Date.now() / 1000, i = -1;
  for (var k = 0; k < events.length; k++) if (events[k].st <= now && now < events[k].st + events[k].d) i = k;
  var name = $.NSProcessInfo.processInfo.environment.objectForKey("NAME").js;
  if (i < 0) return JSON.stringify({label: name, value: "No listing", detail: ""});
  function hm(t) { var x = new Date(t * 1000); return ("0" + x.getHours()).slice(-2) + ":" + ("0" + x.getMinutes()).slice(-2); }
  function clean(t) { return t.indexOf("New: ") == 0 ? t.slice(5) : t; }
  var cur = events[i], nxt = events[i + 1];
  var left = Math.max(0, Math.round((cur.st + cur.d - now) / 60));
  return JSON.stringify({
    label: name,
    value: clean(cur.t),
    detail: "until " + hm(cur.st + cur.d) + " (" + left + " min)" + (nxt ? " · next: " + clean(nxt.t) : ""),
    color: "cyan"
  });
}'
